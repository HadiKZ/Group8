x = lambda a : (round((a/10)*2)/2)*10
print(x(83))