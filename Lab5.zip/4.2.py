import os

try:
    os.mkdir('input_files')
except OSError:
    pass

#path = os.getcwd
f = open('input_files/4.2.txt','w')
f.write('Mojtaba Shahin')