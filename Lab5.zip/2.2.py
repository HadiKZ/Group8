from functools import reduce
a = [['mojtaba','shahin'], ['hadi','kazemi'], ['sina','bagheri']]
b = [reduce(lambda i,j: i+' '+j, a[k]) for k in range(3)]
print(b)