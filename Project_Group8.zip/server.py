import flask
import os


server = flask.Flask(__name__)
@server.route("/")  # Setting the directory of web-server
def Query():
	key = flask.request.args.get('key')
	pictures = os.listdir('/home') # read the list of files at directory
	name = [i.split('.')[0] for i in pictures] # using name of files as key
	Data = dict(zip(name,pictures)) # making (key,value) items
	if key in Data:
		return flask.send_file('/home/'+Data[key],as_attachment=False)  # for downloading the image set as_attachment true
	else:
		return 'Requested File Not Found'
if __name__ == '__main__':
	server.run(host='0.0.0.0',port=3000)
