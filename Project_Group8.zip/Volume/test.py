import os

key = 1
pictures = os.listdir()
ID = [i.split('.')[0] for i in pictures]
List = dict(zip(ID,pictures))
print(List['1'])
